package datasource;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListSelectionModel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

/**
 * 
 * @author LEANDRO
 */
public class DBTableModel implements TableModel {
    
    private class PropertyChangeListenerImpl implements PropertyChangeListener {
        @Override
        public void propertyChange(PropertyChangeEvent evt) {
            JTable jTable = (JTable) evt.getSource();
            if (evt.getPropertyName().equals("model")) {
                for (DBTableColumnModel col : columns) {
                    int width = col.getColumnWidth(); 
                    int idx = (col.getColumnNum() - 1);
                    if (width >= 0) {
                        TableColumn tc = jTable.getColumnModel().getColumn(idx);
                        tc.setMinWidth(width);
                        tc.setWidth(width);
                        if (!resizingAllowed) {
                            tc.setMaxWidth(width);
                        }
                    }            
                }
            }
        }        
    }
    
    private class DBTableColumnModel {

        private int columnNum;
        private int queryField;
        private int columnWidth;
        private String columnTitle;
        private boolean editable;
        private Class columnClass;

        public DBTableColumnModel(int columnNum, int queryField, String columnTitle, 
        boolean editable, Class columnClass, int columnWidth) {
            this.columnNum = columnNum;
            this.queryField = queryField;
            this.columnTitle = columnTitle;
            this.editable = editable;
            this.columnClass = columnClass;
            this.columnWidth = columnWidth;
        }

        public int getColumnNum() {
            return columnNum;
        }

        public int getQueryField() {
            return queryField;
        }

        public String getColumnTitle() {
            return columnTitle;
        }

        public Class getColumnClass() {
            return columnClass;
        }

        public int getColumnWidth() {
            return columnWidth;
        }

        public boolean isEditable() {
            return editable;
        }

        public void setQueryField(int queryField) {
            this.queryField = queryField;
        }

        public void setColumnNum(int columnNum) {
            this.columnNum = columnNum;
        }

        public void setColumnTitle(String columnTitle) {
            this.columnTitle = columnTitle;
        }

        public void setEditable(boolean editable) {
            this.editable = editable;
        }

        public void setColumnClass(Class columnClass) {
            this.columnClass = columnClass;
        }

        public void setColumnWidth(int columnWidth) {
            this.columnWidth = columnWidth;
        }

    }
    
    private PropertyChangeListenerImpl propertyChangeListener;
    private ListSelectionModel listSelectionModel;
    private final ListSelectionListener[] listSelectionListeners;
    private final PreparedStatement preparedStatement;
    private final ResultSet resultSet;
    private final ResultSetMetaData rsetMetadata;
    private final List<DBTableColumnModel> columns = new ArrayList<>();
    private boolean resizingAllowed;
    private JTable source;
    private Object[][] model;    
    private final int rowCount;

    public DBTableModel(PreparedStatement statement, 
    ListSelectionListener ... listeners) throws SQLException {
        if (statement.getResultSetType() != ResultSet.TYPE_SCROLL_INSENSITIVE) {
            throw new SQLException("Tipo de resultset inválido. Use " +
            "ResultSet.TYPE_SCROLL_INSENSITIVE");
        }
        propertyChangeListener = new PropertyChangeListenerImpl();
        this.listSelectionListeners = listeners;
        this.preparedStatement = statement;
        this.resultSet = this.preparedStatement.executeQuery();
        this.rsetMetadata = this.resultSet.getMetaData();
        resultSet.last();
        rowCount = resultSet.getRow();              
    }

    public void setColumn(int columnNum, int queryField, String columnTitle, 
    boolean isEditable, Class columnClass, int columnWidth) {
        for (DBTableColumnModel c : columns) {
            if (c.getColumnNum() == columnNum) {
                c.setQueryField(queryField);
                c.setColumnTitle(columnTitle);
                c.setEditable(isEditable);
                c.setColumnClass(columnClass);
                c.setColumnWidth(columnWidth);
                return;
            }            
        }
        DBTableColumnModel col = new DBTableColumnModel(
            columnNum, 
            queryField, 
            columnTitle, 
            isEditable,
            columnClass,
            columnWidth
        );
        columns.add(col);
    }
    
    public void setColumn(int columnNum, int queryField, String columnTitle) {
        setColumn(
            columnNum, 
            queryField, 
            columnTitle, 
            false, 
            java.lang.Object.class,
            -1
        );
    }
    
    public void setColumn(int columnNum, int queryField, String columnTitle, 
    int columnWidth) {
        setColumn(
            columnNum, 
            queryField, 
            columnTitle, 
            false, 
            java.lang.Object.class,
            columnWidth
        );
    }
    
    public void setColumn(int columnNum, int queryField, String columnTitle, 
    Class columnClass) {
        setColumn(
            columnNum, 
            queryField, 
            columnTitle, 
            false, 
            columnClass,
            -1
        );
    }
    
    public void setColumn(int columnNum, int queryField, String columnTitle, 
    Class columnClass, int columnWidth) {
        setColumn(
            columnNum, 
            queryField, 
            columnTitle, 
            false, 
            columnClass,
            columnWidth
        );
    }
    
    public void setColumn(int columnNum, int queryField, boolean isEditable) 
    throws SQLException, SQLException, SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            isEditable,
            java.lang.Object.class,
            -1
        );
    }   
    
    public void setColumn(int columnNum, int queryField, boolean isEditable,
    int columnWidth) throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            isEditable,
            java.lang.Object.class,
            columnWidth
        );
    }
    
    public void setColumn(int columnNum, int queryField, boolean isEditable,
    Class columnClass) throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            isEditable,
            columnClass,
            -1
        );    
    }
    
    public void setColumn(int columnNum, int queryField, boolean isEditable,
    Class columnClass, int columnWidth) throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            isEditable,
            columnClass,
            columnWidth
        );    
    }
    
    public void setColumn(int columnNum, int queryField) 
    throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            false,
            java.lang.Object.class,
            -1
        );
    }
    
    public void setColumn(int columnNum, int queryField, int columnWidth) 
    throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            false,
            java.lang.Object.class,
            columnWidth
        );    
    }
    
    public void setColumn(int columnNum, int queryField, Class columnClass) 
    throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            false,
            columnClass,
            -1
        );
    }
    
    public void setColumn(int columnNum, int queryField, Class columnClass, 
    int columnWidth) throws SQLException {
        setColumn(
            columnNum, 
            queryField, 
            rsetMetadata.getColumnLabel(queryField),
            false,
            columnClass,
            columnWidth
        );
    }

    @Override
    public int getRowCount() {
        return rowCount;        
    }

    @Override
    public int getColumnCount() {
        int size;
        try {        
            if (columns.size() > 0) {
                size = columns.size();
            } else {
                size = rsetMetadata.getColumnCount();            
            }
        } catch (SQLException ex) {
            size = -1;
        }
        return size;
    }

    @Override
    public String getColumnName(int columnIndex) {
        try {
            if (columns.size() > 0) {
                DBTableColumnModel cm = columns.get(columnIndex);
                return cm.getColumnTitle();
            } else {            
                return rsetMetadata.getColumnLabel(columnIndex + 1);            
            }
        } catch (SQLException ex) {
            return null;
        }
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columns.size() > 0) {
            DBTableColumnModel cm = columns.get(columnIndex);
            return cm.getColumnClass();
        } else {
            return Object.class;
        }
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if (columns.size() > 0) {
            DBTableColumnModel cm = columns.get(columnIndex);
            return cm.isEditable();
        } else {
            return false;
        }
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return model[rowIndex][columnIndex];
    }
    
        @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        model[rowIndex][columnIndex] = aValue;
    }    

    @Override
    public void addTableModelListener(TableModelListener l) { 
       try {
            if (l instanceof JTable) {
                this.source = (JTable) l;
                int selectionMode = source.getSelectionModel().getSelectionMode();
                boolean reorderingAllowed = source.getTableHeader().getReorderingAllowed();
                resizingAllowed = source.getTableHeader().getResizingAllowed();
                if (columns.size() > 0) {
                    model = new Object[rowCount][columns.size()];                
                    for (int i1 = 0; i1 < rowCount; i1++) {
                        resultSet.absolute(i1 + 1);
                        for (int i2 = 0; i2 < columns.size(); i2++) {
                            DBTableColumnModel cm = columns.get(i2);
                            model[i1][i2] = resultSet.getObject(cm.getQueryField());
                        }                    
                    }                    
                } else {
                    int colCount = rsetMetadata.getColumnCount();
                    model = new Object[rowCount][colCount];                
                    for (int i1 = 0; i1 < rowCount; i1++) {
                        resultSet.absolute(i1 + 1);
                        for (int i2 = 0; i2 < colCount; i2++) {
                            model[i1][i2] = resultSet.getObject(i2);                       
                        }                    
                    }                    
                }  
                listSelectionModel = new DefaultListSelectionModel() {  
                    @Override
                    public void setSelectionInterval(int index0, int index1) {
                        super.setSelectionInterval(index0, index1);
                        if (index0 >= 0) {                                
                            try {
                                resultSet.absolute(index0 + 1);
                                ListSelectionEvent e = new ListSelectionEvent(source,
                                index0, index1, false);
                                for (ListSelectionListener l : listSelectionListeners) {
                                    l.valueChanged(e);
                                }
                            } catch (SQLException ex) {
                                throw new RuntimeException(ex.getMessage());
                            }
                        }                        
                    }                       
                } ;
                source.setSelectionModel(listSelectionModel);
                source.setAutoCreateRowSorter(false);
                source.setSelectionMode(selectionMode);
                source.getTableHeader().setReorderingAllowed(reorderingAllowed);
                source.getTableHeader().setResizingAllowed(resizingAllowed);
                source.addPropertyChangeListener(propertyChangeListener);
            }
        } catch (SQLException ex) {
            throw new RuntimeException(ex.toString());
        }
    }
    
    @Override
    public void removeTableModelListener(TableModelListener l) {        
        source.setSelectionModel(new DefaultListSelectionModel());
        source.removePropertyChangeListener(propertyChangeListener);
        listSelectionModel = null;
        propertyChangeListener = null;
        System.gc();
        try {
            resultSet.close();
            preparedStatement.close();            
        } catch (SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    } 
      
}