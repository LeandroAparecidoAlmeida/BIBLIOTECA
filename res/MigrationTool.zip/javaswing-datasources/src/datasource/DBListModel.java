package datasource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JList;
import javax.swing.ListModel;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class DBListModel implements ListModel<Object> {
    
    private class ListSelectionListenerImpl implements 
    ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            try {
                int idx = ((JList) e.getSource()).getSelectedIndex();
                preparedStatement.getResultSet().absolute(idx + 1);
            } catch (SQLException ex) {
                throw new RuntimeException(ex.getMessage());
            }
        }                
    }
    
    private final JList source;  
    private final ListSelectionListenerImpl listener;
    private final PreparedStatement preparedStatement;        
    private final List<Object> itens;

    public DBListModel(JList source, PreparedStatement statement, int fieldNum) 
    throws SQLException {
        if (statement.getResultSetType() != ResultSet.TYPE_SCROLL_INSENSITIVE) {
            throw new SQLException("Tipo de resultset inválido. Use " +
            "ResultSet.TYPE_SCROLL_INSENSITIVE");
        }
        this.source = source;
        this.preparedStatement = statement;
        ResultSet r = this.preparedStatement.executeQuery();
        itens = new ArrayList<>();
        listener = new ListSelectionListenerImpl();
        r.beforeFirst();
        while (r.next()) {        
            itens.add(r.getObject(fieldNum));            
        }
    }

    @Override
    public int getSize() {
        return itens.size();
    }

    @Override
    public Object getElementAt(int index) {
        return itens.get(index);
    }

    @Override
    public void addListDataListener(ListDataListener l) { 
        source.addListSelectionListener(listener);
    }

    @Override
    public void removeListDataListener(ListDataListener l) {
        source.removeListSelectionListener(listener);
        try {
            preparedStatement.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }
    
}
