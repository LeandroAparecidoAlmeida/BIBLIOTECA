package datasource;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.event.ListDataListener;

/**
 * Datasource para geração de dados para um componente {@link JComboBox} a 
 * partir de uma consulta executada no banco de dados. Com a atribuição
 * deste datasource, quando o usuário seleciona um item no JComboBox, a
 * classe faz com que o cursor do {@link ResultSet} da consulta movimente
 * para o registro correspondente, refletindo a ação do usuário.
 * @since 1.0
 * @author Leandro Aparecido de Almeida
 */
public class DBComboboxModel implements ComboBoxModel<Object> {
    
    /**
     * Implementação de {@link ItemListener}. Sua função é a de fazer
     * com que o cursor do ResultSet movimente para a posição correspondente
     * ao elemento selecionado no JComboBox.
     */
    private class ItemListenerImpl implements ItemListener {
        @Override
        public void itemStateChanged(ItemEvent e) {
            try {
                if (e.getStateChange() == ItemEvent.SELECTED) { 
                    int idx = ((JComboBox) e.getSource()).getSelectedIndex();
                    preparedStatement.getResultSet().absolute(idx + 1);
                }
            } catch (SQLException ex) {
                throw new RuntimeException(ex.getMessage());
            }
        }        
    }
    
    /**JComboBox de origem a que foi atribuído do datasource.*/
    private JComboBox source; 
    /**Consulta SQL executada no banco de dados.*/
    private final PreparedStatement preparedStatement; 
    /**Ouvinte de seleção de item no JComboBox.*/
    private final ItemListenerImpl listener;
    /**Itens listados na JCombobox.*/
    private final List<Object> itens;
    /**Item selecionado na JComboBox.*/
    private Object obj;
    
    /**
     * Criar uma instância da classe.
     * @param statement consulta SQL a ser executada no banco de dados.
     * @param fieldNum posição do campo na consulta de onde serão extraídos
     * os dados para o preenchimento do JComboBox.
     * @throws SQLException erro no acesso ao banco de dados ou tipo
     * de consulta ao banco de dados inválida.
     */
    public DBComboboxModel(PreparedStatement statement, int fieldNum) throws SQLException {
        if (statement.getResultSetType() != ResultSet.TYPE_SCROLL_INSENSITIVE) {
            throw new SQLException("Tipo de resultset inválido. Use " +
            "ResultSet.TYPE_SCROLL_INSENSITIVE.");
        }
        this.preparedStatement = statement;
        ResultSet r = this.preparedStatement.executeQuery();
        listener = new ItemListenerImpl();
        itens = new ArrayList<>();
        r.beforeFirst();
        while (r.next()) {
            itens.add(r.getObject(fieldNum));            
        }
    }

    @Override
    public void setSelectedItem(Object anItem) {
        obj = anItem; 
    }

    @Override
    public Object getSelectedItem() {
        return obj;
    }

    @Override
    public int getSize() {
        return itens.size();
    }

    @Override
    public Object getElementAt(int index) {
        return itens.get(index);
    }

    @Override
    public void addListDataListener(ListDataListener l) {
        if (l instanceof JComboBox) {
            source = (JComboBox) l;
            source.addItemListener(listener);            
        }
    }
    
    @Override
    public void removeListDataListener(ListDataListener l) {
        source.removeItemListener(listener);
        try {
            preparedStatement.close();
        } catch (SQLException ex) {
            throw new RuntimeException(ex.getMessage());
        }
    }    
    
}