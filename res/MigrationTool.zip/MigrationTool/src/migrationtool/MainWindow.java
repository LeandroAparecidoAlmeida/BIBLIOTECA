package migrationtool;

import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

public class MainWindow extends javax.swing.JFrame {

    public MainWindow() {
        initComponents();
    }
   
    private void migrate() {
        try {
            FBManager srcManager = new FBManager(new File(jtfSourceDatabase.getText()), "SYSDBA", "123");
            FBManager tarManager = new FBManager(new File(jtfTargetDatabase.getText()), "SYSDBA", "123");
            try (Connection srcConnection = srcManager.getConnection();
            Connection tarConnection = tarManager.getConnection()) {
                int max = 0;
                int count =0;
                String sql1 =
                "SELECT " +
                    "COUNT(*) " +
                "FROM LIVRO;";
                try (PreparedStatement pstm1 = srcConnection.prepareStatement(sql1,
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); 
                ResultSet rset = pstm1.executeQuery()) {
                    if (rset.first()) {
                        max = rset.getInt(1);
                    }
                }
                jpbMigration.setMinimum(0);
                jpbMigration.setMaximum(max);
                String sql2 =
                "SELECT " +
                    "TITULO, " +
                    "SUBTITULO, " +
                    "AUTOR, " +
                    "EDITORA, " +
                    "ISBN, " +
                    "ANO_PUBLICACAO, " +
                    "DATA_AQUISICAO, " +
                    "EDICAO, " +
                    "VOLUME, " +
                    "NUM_PAGS, " +
                    "RESUMO, " +
                    "CAPA " +
                "FROM LIVRO " +
                "ORDER BY 1;";
                try (PreparedStatement pstm2 = srcConnection.prepareStatement(sql2,
                ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY); 
                ResultSet rset = pstm2.executeQuery()) {
                    String sql3 =
                    "INSERT INTO BOOK(TITLE, SUBTITLE, AUTHOR, PUBLISHER, ISBN," +
                    "ISSUE_YEAR, PURCHASE_DATE, EDITION, VOLUME, NUM_PAGES, " +
                    "SUMMARY, COVER) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
                    rset.beforeFirst();
                    while (rset.next()) {
                        try (PreparedStatement pstm3 = tarConnection.prepareStatement(sql3)) {
                            pstm3.setString(1, rset.getString(1));
                            pstm3.setString(2, rset.getString(2));
                            pstm3.setString(3, rset.getString(3));
                            pstm3.setString(4, rset.getString(4));
                            pstm3.setString(5, rset.getString(5));
                            pstm3.setInt(6, rset.getInt(6));
                            pstm3.setDate(7, rset.getDate(7));
                            pstm3.setInt(8, rset.getInt(8));
                            pstm3.setInt(9, rset.getInt(9));
                            pstm3.setInt(10, rset.getInt(10));
                            pstm3.setString(11, rset.getString(11));
                            pstm3.setBlob(12, rset.getBlob(12));
                            pstm3.executeUpdate();
                        }
                        count++;
                        jpbMigration.setValue(count);
                    }                    
                }           
            }
            JOptionPane.showMessageDialog(this, "Migração concluída.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jtfSourceDatabase = new javax.swing.JTextField();
        jtfTargetDatabase = new javax.swing.JTextField();
        jpbMigration = new javax.swing.JProgressBar();
        jLabel3 = new javax.swing.JLabel();
        jbInit = new javax.swing.JButton();
        jbPause = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Banco de Dados de Origem:");

        jLabel2.setText("Banco de Dados de Destino:");

        jpbMigration.setStringPainted(true);

        jLabel3.setText("Progresso da Migração:");

        jbInit.setText("Iniciar");
        jbInit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbInitActionPerformed(evt);
            }
        });

        jbPause.setText("Interromper");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(103, Short.MAX_VALUE)
                .addComponent(jbInit, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jbPause, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(98, 98, 98))
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jtfSourceDatabase, javax.swing.GroupLayout.DEFAULT_SIZE, 539, Short.MAX_VALUE)
                    .addComponent(jtfTargetDatabase))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jpbMigration, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfSourceDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jtfTargetDatabase, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jpbMigration, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 91, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbInit)
                    .addComponent(jbPause))
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbInitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbInitActionPerformed
        new Thread() {
            @Override
            public void run() {
                migrate();
            } 
        }.start();
    }//GEN-LAST:event_jbInitActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(MainWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton jbInit;
    private javax.swing.JButton jbPause;
    private javax.swing.JProgressBar jpbMigration;
    private javax.swing.JTextField jtfSourceDatabase;
    private javax.swing.JTextField jtfTargetDatabase;
    // End of variables declaration//GEN-END:variables
}
