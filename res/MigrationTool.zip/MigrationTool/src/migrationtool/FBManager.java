package migrationtool;

import java.io.File;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class FBManager {

    private final static String ENCODING = "ISO8859_1";
    private final String url;
    private String userName;
    private String password;
    
    static {
        try {
            Driver driver = (Driver) Class.forName("org.firebirdsql.jdbc.FBDriver")
            .newInstance();
            DriverManager.registerDriver(driver);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public FBManager(File fbFile, String userName, String password) throws ClassNotFoundException, 
    InstantiationException, IllegalAccessException, SQLException {               
        url = "jdbc:firebirdsql:localhost/3050:" + fbFile.getAbsolutePath() + 
        "?encoding=" + ENCODING;
        this.userName = userName;
        this.password = password;
    }

    public Connection getConnection(boolean autoCommit) throws SQLException {  
        Connection connection = DriverManager.getConnection(url, userName, password);
        connection.setAutoCommit(autoCommit);
        return connection;
    }

    public Connection getConnection() throws SQLException { 
        return getConnection(true);
    }
    
}